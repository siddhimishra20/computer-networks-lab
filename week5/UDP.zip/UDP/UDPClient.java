import java.io.*;
import java.net.*;
import java.util.*;

public class UDPClient {
    public static void main(String[] args) throws IOException {
        Scanner sc = new Scanner(System.in);
        DatagramSocket ds = new DatagramSocket();
        InetAddress ip = InetAddress.getLocalHost();
        byte[] buf = null;

        System.out.println("UDP Client ready. Enter operation or 'bye' to quit:");

        while (true) {
            System.out.print("> ");
            String inp = sc.nextLine();

            buf = inp.getBytes();
            DatagramPacket dpSend = new DatagramPacket(buf, buf.length, ip, 1234);
            ds.send(dpSend);

            if (inp.equals("bye")) break;

            byte[] receive = new byte[65535];
            DatagramPacket dpReceive = new DatagramPacket(receive, receive.length);
            ds.receive(dpReceive);
            System.out.println("Server: " + new String(dpReceive.getData(), 0, dpReceive.getLength()));
        }
        sc.close();
        ds.close();
    }
}
