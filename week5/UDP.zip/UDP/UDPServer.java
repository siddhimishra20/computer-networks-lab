import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

public class UDPServer {
    public static void main(String[] args) throws IOException {
        DatagramSocket ds = new DatagramSocket(1234);
        byte[] receive = new byte[65535];
        DatagramPacket dpReceive = null;

        System.out.println("UDP Server listening on port 1234...");

        while (true) {
            dpReceive = new DatagramPacket(receive, receive.length);
            ds.receive(dpReceive);

            String request = dataToString(receive);
            System.out.println("Client: " + request);

            if (request.equals("bye")) {
                System.out.println("Client sent bye...Leaving");
                break;
            }

            String result = processRequest(request);
            System.out.println("Result: " + result);

            byte[] buf = result.getBytes();
            InetAddress ip = dpReceive.getAddress();
            int port = dpReceive.getPort();
            DatagramPacket dpSend = new DatagramPacket(buf, buf.length, ip, port);
            ds.send(dpSend);

            receive = new byte[65535];
        }
        ds.close();
    }

    private static String processRequest(String request) {
        try {
            String[] parts = request.trim().split("\\s+");
            if (parts.length != 3) return "ERROR: format is: num1 operator num2";
            double a = Double.parseDouble(parts[0]);
            String op = parts[1];
            double b = Double.parseDouble(parts[2]);
            double result;
            switch (op) {
                case "+": result = a + b; break;
                case "-": result = a - b; break;
                case "*": result = a * b; break;
                case "/":
                    if (b == 0) return "ERROR: division by zero";
                    result = a / b; break;
                default: return "ERROR: unknown operator (use +, -, *, /)";
            }
            if (result == (long) result)
                return String.valueOf((long) result);
            return String.valueOf(result);
        } catch (NumberFormatException e) {
            return "ERROR: invalid numbers";
        }
    }

    private static String dataToString(byte[] a) {
        if (a == null) return null;
        StringBuilder ret = new StringBuilder();
        int i = 0;
        while (a[i] != 0) {
            ret.append((char) a[i]);
            i++;
        }
        return ret.toString();
    }
}
