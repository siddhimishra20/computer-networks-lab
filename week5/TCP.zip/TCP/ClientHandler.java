import java.io.*;
import java.net.*;

public class ClientHandler implements Runnable {
    private final Socket clientSocket;

    public ClientHandler(Socket socket) {
        this.clientSocket = socket;
    }

    public void run() {
        try (
            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true)
        ) {
            String operation;
            while ((operation = in.readLine()) != null) {
                String input = in.readLine();
                if (input == null) break;
                String result = processRequest(operation, input);
                out.println(result);
                System.out.println("[Server] " + operation + "(" + input + ") = " + result);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try { clientSocket.close(); } catch (IOException e) { e.printStackTrace(); }
        }
    }

    private String processRequest(String operation, String input) {
        if (operation == null || input == null) return "ERROR: null input";
        switch (operation.trim().toUpperCase()) {
            case "FACTORIAL": {
                try {
                    int n = Integer.parseInt(input.trim());
                    if (n < 0) return "ERROR: negative input";
                    long result = 1;
                    for (int i = 2; i <= n; i++) result *= i;
                    return String.valueOf(result);
                } catch (NumberFormatException e) {
                    return "ERROR: invalid number";
                }
            }
            case "FIBONACCI": {
                try {
                    int n = Integer.parseInt(input.trim());
                    if (n < 0) return "ERROR: negative input";
                    if (n == 0) return "0";
                    if (n == 1) return "1";
                    long a = 0, b = 1;
                    for (int i = 2; i <= n; i++) {
                        long tmp = a + b;
                        a = b;
                        b = tmp;
                    }
                    return String.valueOf(b);
                } catch (NumberFormatException e) {
                    return "ERROR: invalid number";
                }
            }
            case "PRIME": {
                try {
                    int n = Integer.parseInt(input.trim());
                    if (n < 2) return n + " is Not Prime";
                    for (int i = 2; i <= Math.sqrt(n); i++) {
                        if (n % i == 0) return n + " is Not Prime";
                    }
                    return n + " is Prime";
                } catch (NumberFormatException e) {
                    return "ERROR: invalid number";
                }
            }
            case "REVERSE": {
                return new StringBuilder(input.trim()).reverse().toString();
            }
            default:
                return "ERROR: unknown operation";
        }
    }
}
