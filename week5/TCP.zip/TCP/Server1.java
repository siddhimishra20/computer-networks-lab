import java.io.*;
import java.net.*;

public class Server1 {
    public static void main(String[] args) {
        try (ServerSocket server = new ServerSocket(8010)) {
            server.setReuseAddress(true);
            System.out.println("[Sequential Server] Listening on port 8010...");
            int clientCount = 0;
            while (true) {
                Socket client = server.accept();
                clientCount++;
                System.out.println("[Server1] Client " + clientCount + " connected: "
                        + client.getInetAddress().getHostAddress());
                new ClientHandler(client).run();
                System.out.println("[Server1] Done with client " + clientCount);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
