import java.io.*;
import java.net.*;
import java.util.Scanner;

public class Client4 {
    public static void main(String[] args) throws IOException {
        int port = (args.length > 0) ? Integer.parseInt(args[0]) : 8010;
        Scanner sc = new Scanner(System.in);
        try (Socket socket = new Socket("localhost", port);
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {

            System.out.println("Client 4 - Reverse String. Type a word (or 'exit' to quit):");
            while (true) {
                System.out.print("Enter string: ");
                String input = sc.nextLine();
                if (input.equalsIgnoreCase("exit")) break;
                out.println("REVERSE");
                out.println(input);
                System.out.println("Server: " + in.readLine());
            }
        }
        sc.close();
    }
}
