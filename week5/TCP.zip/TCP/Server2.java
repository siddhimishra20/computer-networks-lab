import java.io.*;
import java.net.*;

public class Server2 {
    public static void main(String[] args) {
        try (ServerSocket server = new ServerSocket(8011)) {
            server.setReuseAddress(true);
            System.out.println("[Threaded Server] Listening on port 8011...");
            int clientCount = 0;
            while (true) {
                Socket client = server.accept();
                clientCount++;
                System.out.println("[Server2] Client " + clientCount + " connected: "
                        + client.getInetAddress().getHostAddress());
                new Thread(new ClientHandler(client)).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
